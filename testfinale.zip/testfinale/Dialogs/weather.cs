﻿using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using System;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using testfinale.Dialogs.tasks;

namespace testfinale.Dialogs
{
    public class weather : CancelAndHelpDialog
    {
        private readonly HttpClient httpClient;
        public weather(HttpClient httpClient) : base(nameof(weather))
        {
            this.httpClient = httpClient;
            var WaterFallSteps = new WaterfallStep[]
           {
               IntroStepAsync,
               
                getweatherapiAsync ,
                endStepAsync
           };
            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), WaterFallSteps));
            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(new ConfirmPrompt(nameof(ConfirmPrompt)));

            InitialDialogId = nameof(WaterfallDialog);
        }

        private async Task<DialogTurnResult> IntroStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("please enter the city")
            }, cancellationToken);
        }

        private async Task<DialogTurnResult> getweatherapiAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            try
        {
                var apiKey = "4f5d8cb093b3b2c29453d226575174b5";
                var city = (string)stepContext.Result;

                var url = "https://api.coindesk.com/v1/bpi/currentprice.json";
               

                var response = await httpClient.GetAsync(url);

                if (response.IsSuccessStatusCode)
                {
                    var catData = await response.Content.ReadAsStringAsync();

                    // Process weather data and send a response
                    await stepContext.Context.SendActivityAsync($"Here's the current weather data for {city}: {catData}");
                }
                else
                {
                    // Handle unsuccessful API call
                    await stepContext.Context.SendActivityAsync($"Failed to retrieve weather data. Status code: {response.StatusCode}");
                }
            }
        catch (Exception ex)
        {
                // Handle exceptions
                await stepContext.Context.SendActivityAsync($"An error occurred: {ex.Message}");
            }

            return await stepContext.PromptAsync(nameof(ConfirmPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Would you like to look for another city")
            }, cancellationToken);
        }

        private async Task<DialogTurnResult> endStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if ((bool)stepContext.Result)
            {
                return await stepContext.ReplaceDialogAsync(InitialDialogId, null, cancellationToken);
            }
            else
            {
                return await stepContext.EndDialogAsync(null, cancellationToken);
            }
        }
    }
}
