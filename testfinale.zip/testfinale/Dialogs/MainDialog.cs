﻿// Generated with Bot Builder V4 SDK Template for Visual Studio CoreBot v4.22.0

using AdaptiveCards;
using testfinale;
using testfinale.Dialogs.tasks;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Dialogs.Choices;
using Microsoft.Bot.Schema;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.Extensions.Logging;
using Microsoft.Recognizers.Text.DataTypes.TimexExpression;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using testfinale;
using testfinale.Dialogs.tasks;
using CoreBotWithTests1.Dialogs.tasks;
using testfinale.utility;
using System.Net.Http;
using testfinale.CognitiveModels;
using Microsoft.BotBuilderSamples;
using System.Diagnostics;
using testfinale.Models;

namespace testfinale.Dialogs
{
    public class MainDialog : ComponentDialog
    {
        private readonly ILogger _logger;
        private readonly testfinaleRecognizer _luisRecognizer;
        private readonly IUserRepository _userRepository;
        private readonly FlightBookingRecognizer _cluRecognizer;

        // Dependency injection uses this constructor to instantiate MainDialog
        public MainDialog(FlightBookingRecognizer cluRecognizer, testfinaleRecognizer luisRecognizer, ILogger<MainDialog> logger, IUserRepository userRepository, HttpClient httpclient)
            : base(nameof(MainDialog))
        {
            _luisRecognizer = luisRecognizer;
            _cluRecognizer = cluRecognizer;
            _logger = logger;
            _userRepository = userRepository;

            AddDialog(new TextPrompt(nameof(TextPrompt)));

            AddDialog(new ChoicePrompt(nameof(ChoicePrompt)));


            AddDialog(new addinvoice());
            AddDialog(new addmoreinvoice());
            AddDialog(new view());
            AddDialog(new deleteinvoice());
            AddDialog(new ReadUser(userRepository));
            AddDialog(new usertasks(userRepository));
            AddDialog(new weather(httpclient));
            AddDialog(new InsertUser(userRepository));
            AddDialog(new ReadUser(userRepository));
            AddDialog(new welcome());



            var waterfallSteps = new WaterfallStep[]
            {
                HiStepAsync,
                CluStepAsync,
                IntroStepAsync,
                ActStepAsync,
                FinalStepAsync


            };

            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), waterfallSteps));

            // The initial child Dialog to run.
            InitialDialogId = nameof(WaterfallDialog);
        }

        private async Task<DialogTurnResult> HiStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if (!_cluRecognizer.IsConfigured)
            {
                await stepContext.Context.SendActivityAsync(
                    MessageFactory.Text("NOTE: CLU is not configured. To enable all capabilities, add 'CluProjectName', 'CluDeploymentName', 'CluAPIKey' and 'CluAPIHostName' to the appsettings.json file.", inputHint: InputHints.IgnoringInput), cancellationToken);

                return await stepContext.NextAsync(null, cancellationToken);
            }

            // Use the text provided in FinalStepAsync or the default if it is the first time.
            var weekLaterDate = DateTime.Now.AddDays(7).ToString("MMMM d, yyyy");
            var messageText = stepContext.Options?.ToString() ?? $"What can I help you with today?";
            var promptMessage = MessageFactory.Text(messageText, messageText, InputHints.ExpectingInput);
            return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = promptMessage }, cancellationToken);
        }



        private async Task<DialogTurnResult> CluStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            // Call CLU and gather any potential booking details. (Note the TurnContext has the response to the prompt.)
            var cluResult = await _cluRecognizer.RecognizeAsync<FlightBooking>(stepContext.Context, cancellationToken);
            switch (cluResult.GetTopIntent().intent)
            {
                case FlightBooking.Intent.greeting:

                    var message = "hi how can i help you today";
                    var messagesent = MessageFactory.Text(message, message, InputHints.IgnoringInput);
                    await stepContext.Context.SendActivityAsync(messagesent, cancellationToken);
                    break;




                //case FlightBooking.Intent.getweather:


                //    await stepContext.BeginDialogAsync(nameof(weather), new user(), cancellationToken);
                //    break;
                case FlightBooking.Intent.CreateInvoice:
                    var userdetails = new user()
                    {
                        name = cluResult.Entities.GetfromName()
                    };
                    return await stepContext.BeginDialogAsync(nameof(addinvoice), userdetails, cancellationToken);


                case FlightBooking.Intent.ViewInvoice:


                    await stepContext.BeginDialogAsync(nameof(view), new user(), cancellationToken);
                    break;
                case FlightBooking.Intent.DeleteInvoice:


                    await stepContext.BeginDialogAsync(nameof(view), new user(), cancellationToken);
                    break;
                case FlightBooking.Intent.ReadUser:
                    var userdetails3 = new User()
                    {
                        UId = cluResult.Entities.GetFromUserID(),
                        UName = cluResult.Entities.GetfromName(),
                    };


                    return await stepContext.BeginDialogAsync(nameof(ReadUser), userdetails3, cancellationToken);

                case FlightBooking.Intent.AddUser:

                    var userdetails2 = new User()
                    {
                        UId = cluResult.Entities.GetFromUserID(),
                        UName = cluResult.Entities.GetfromName(),
                    };

                    return await stepContext.BeginDialogAsync(nameof(InsertUser), userdetails2, cancellationToken);

                //case FlightBooking.Intent.userdetails:


                //    await stepContext.BeginDialogAsync(nameof(usertasks),new User(), cancellationToken);
                //    break;

                default:
                    // Catch all for unhandled intents
                    var didntUnderstandMessageText = $"Sorry, I didn't get that. Please try asking in a different way (intent was {cluResult.GetTopIntent().intent})";
                    var didntUnderstandMessage = MessageFactory.Text(didntUnderstandMessageText, didntUnderstandMessageText, InputHints.IgnoringInput);
                    await stepContext.Context.SendActivityAsync(didntUnderstandMessage, cancellationToken);
                    break;
            }

            return await stepContext.NextAsync(null, cancellationToken);
        }
        private async Task<DialogTurnResult> IntroStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            await stepContext.Context.SendActivityAsync(MessageFactory.Text("how can i help you today ? "));
            List<string> steps = new List<string> { "create invoice", "delete invoice", "view invoices", "user details", "get weather" };
            return await stepContext.PromptAsync(nameof(ChoicePrompt), new PromptOptions
            {
                Choices = ChoiceFactory.ToChoices(steps),
            }, cancellationToken);


        }
        private async Task<DialogTurnResult> ActStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            stepContext.Values["choices"] = ((FoundChoice)stepContext.Result).Value;
            string operation = (string)stepContext.Values["choices"];
            await stepContext.Context.SendActivityAsync(MessageFactory.Text($"you have selected {operation}"), cancellationToken);
            if ("create invoice".Equals(operation))
            {
                return await stepContext.BeginDialogAsync(nameof(addinvoice), new user(), cancellationToken);
            }
            else if ("delete invoice".Equals(operation))
            {
                return await stepContext.BeginDialogAsync(nameof(deleteinvoice), new user(), cancellationToken);
            }
            else if ("view invoices".Equals(operation))
            {
                return await stepContext.BeginDialogAsync(nameof(view), new user(), cancellationToken);
            }
            else if ("user details".Equals(operation))
            {
                return await stepContext.BeginDialogAsync(nameof(usertasks), new User(), cancellationToken);
            }
            else if ("get weather".Equals(operation))
            {


                return await stepContext.BeginDialogAsync(nameof(weather), new user(), cancellationToken);

            }
            else
            {
                await stepContext.Context.SendActivityAsync(MessageFactory.Text("the selected option not found"), cancellationToken);
            }
            return await stepContext.NextAsync(null, cancellationToken);

        }

        private async Task<DialogTurnResult> FinalStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {


            // Restart the main dialog with a different message the second time around
            var promptMessage = "What else can I do for you?";
            return await stepContext.ReplaceDialogAsync(InitialDialogId, promptMessage, cancellationToken);
        }

    }


}

