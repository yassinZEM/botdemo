﻿using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Dialogs.Choices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace testfinale.Dialogs.tasks
{
    public class view : ComponentDialog
    {
        public view() : base(nameof(view))
        {
            var WaterFallSteps = new WaterfallStep[]
         {
             ActStepAsync ,
             AskStepAsync ,
             DoStepAsync


         };
            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), WaterFallSteps));
            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(new ChoicePrompt(nameof(ChoicePrompt)));

            InitialDialogId = nameof(WaterfallDialog);
        }




        private async Task<DialogTurnResult> AskStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var userdetails = (user)stepContext.Result;
            //stepContext.Values["choices"] = ((FoundChoice)stepContext.Result).Value;
            string operation = (string)stepContext.Result;

            if ("all invoices".Equals(operation))
            {
                for (int i = 0; i < userdetails.invoicelist.Count; i++)
                {
                    await stepContext.Context.SendActivityAsync(MessageFactory.Text(userdetails.invoicelist[i]), cancellationToken);

                }
                return await stepContext.EndDialogAsync(userdetails, cancellationToken);
            }
            else
            {


                return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
                {
                    Prompt = MessageFactory.Text("name the invoice you want to view")

                }, cancellationToken);

            }
        }

        private async Task<DialogTurnResult> ActStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            await stepContext.Context.SendActivityAsync(MessageFactory.Text("would you like to view : "));
            List<string> steps3 = new List<string> { "all invoces", "specific invoice" };
            return await stepContext.PromptAsync(nameof(ChoicePrompt), new PromptOptions
            {
                Choices = ChoiceFactory.ToChoices(steps3),
            }, cancellationToken);
        }

        private Task<DialogTurnResult> DoStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var userdetails = (user)stepContext.Result;

            var x = (string)stepContext.Result;
            return null;
        }

    }

}
