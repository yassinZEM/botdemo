﻿using testfinale.Models;

using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using testfinale.Dialogs;
using testfinale.utility;

namespace testfinale.Dialogs
{
    public class ReadUser : CancelAndHelpDialog
    {
        private readonly IUserRepository _userRepository;
        public ReadUser(IUserRepository userRepository)
            : base(nameof(ReadUser))
        {
            _userRepository = userRepository;

            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(new ChoicePrompt(nameof(ChoicePrompt)));
            AddDialog(new ConfirmPrompt(nameof(ConfirmPrompt)));
            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), new WaterfallStep[]
            {
                IntroStepAsync,
                ActStepAsync,
                FinalStepAsync,
            }));

            // The initial child Dialog to run.
            InitialDialogId = nameof(WaterfallDialog);
        }

        private async Task<DialogTurnResult> IntroStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var userdetails = (User)stepContext.Options;
            var user = new User();

            if (userdetails.UId == null)
            {
                return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
                {
                    Prompt = MessageFactory.Text("Please enter the user Id.")
                }, cancellationToken);
            }
            return await stepContext.NextAsync(userdetails.UId, cancellationToken);
        }

        private async Task<DialogTurnResult> ActStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            stepContext.Values["userId"] = (string)stepContext.Result;
            User user = _userRepository.FetchuserDetails((string)stepContext.Values["userId"]);
            if (user == null)
            {
                await stepContext.Context.SendActivityAsync(MessageFactory.Text($"user with id {(string)stepContext.Values["userId"]} not found."), cancellationToken);
            }
            else
            {
                await stepContext.Context.SendActivityAsync(MessageFactory.Text($"{user.UId} - {user.UName}"), cancellationToken);
            }

            return await stepContext.PromptAsync(nameof(ConfirmPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Would you like to search for more user names?")
            }, cancellationToken);
        }

        private async Task<DialogTurnResult> FinalStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if ((bool)stepContext.Result)
            {
                return await stepContext.ReplaceDialogAsync(InitialDialogId, new User(), cancellationToken);
            }
            else
            {
                return await stepContext.EndDialogAsync(null, cancellationToken);
            }
        }
    }
}