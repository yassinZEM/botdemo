﻿using testfinale.Models;

using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using testfinale.Dialogs;
using testfinale.utility;
using Microsoft.BotBuilderSamples;

namespace testfinale.Dialogs
{
    public class InsertUser : CancelAndHelpDialog
    {
        private readonly IUserRepository _userRepository;
        public InsertUser(IUserRepository userRepository)
            : base(nameof(InsertUser))
        {
            _userRepository = userRepository;

            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(new ChoicePrompt(nameof(ChoicePrompt)));
            AddDialog(new ConfirmPrompt(nameof(ConfirmPrompt)));
            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), new WaterfallStep[]
            {
                userIdStepAsync,
                userNameStepAsync,
                ActStepAsync,
                FinalStepAsync,
            }));

            // The initial child Dialog to run.
            InitialDialogId = nameof(WaterfallDialog);
        }

        private async Task<DialogTurnResult> userIdStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var userdetails = (User)stepContext.Options;
            var user = new User();
           
            if (userdetails.UId == null )
            {
                return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
                {
                    Prompt = MessageFactory.Text("Please enter the user Id.")
                }, cancellationToken);
            }
            return await stepContext.NextAsync(userdetails.UId, cancellationToken);
        }

        private async Task<DialogTurnResult> userNameStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var userdetails = (User)stepContext.Options;
            stepContext.Values["userid"] = (string)stepContext.Result;
            if (userdetails.UName == null)
            {
                return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
                {
                    Prompt = MessageFactory.Text($"Please enter the user Name for id {(string)stepContext.Values["userid"]}")
                }, cancellationToken);
            }
            return await stepContext.NextAsync( userdetails.UName, cancellationToken);
        }

        private async Task<DialogTurnResult> ActStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var userdetails = (User)stepContext.Options;
            stepContext.Values["username"] = (string)stepContext.Result;

            User user = new User();
            user.UId = (string)stepContext.Values["userid"];
            user.UName = (string)stepContext.Values["username"];

            bool status = _userRepository.Insertuser(user);
            if (status)
            {
                await stepContext.Context.SendActivityAsync(MessageFactory.Text("user Inserted"), cancellationToken);
            }
            else
            {
                await stepContext.Context.SendActivityAsync(MessageFactory.Text("user Not Inserted or user already exists"), cancellationToken);
            }

            return await stepContext.PromptAsync(nameof(ConfirmPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Would you like to insert more user details?")
            }, cancellationToken);
        }

        private async Task<DialogTurnResult> FinalStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            
            if ((bool)stepContext.Result)
            {
                
                return await stepContext.ReplaceDialogAsync(InitialDialogId, new User(), cancellationToken);
            }
            else
            {
                return await stepContext.EndDialogAsync(null, cancellationToken);
            }
        }
    }
}