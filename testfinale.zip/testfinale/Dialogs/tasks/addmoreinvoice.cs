﻿using Microsoft.AspNetCore.Http;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace   testfinale.Dialogs.tasks
{
    public class addmoreinvoice : ComponentDialog
    {
        public addmoreinvoice() : base(nameof(addmoreinvoice))
        {
            var WaterFallSteps = new WaterfallStep[]
           {
                TaskStepAsync,
                confirmStepAsync ,
                endStepAsync
           };
            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), WaterFallSteps));
            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(new ConfirmPrompt(nameof(ConfirmPrompt)));

            InitialDialogId = nameof(WaterfallDialog);
        }

        private async Task<DialogTurnResult> TaskStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("what invoice do you want to create")
            }, cancellationToken);
        }

        private async Task<DialogTurnResult> confirmStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var userdetails = (user)stepContext.Options;
            stepContext.Values["invoice"] = (string)stepContext.Result;
            userdetails.invoicelist.Add((string)stepContext.Values["invoice"]);
            return await stepContext.PromptAsync(nameof(ConfirmPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("would you like to add more ivoices")
            }, cancellationToken);
        }
        private async Task<DialogTurnResult> endStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var userdetails = (user)stepContext.Options;
            if ((bool)stepContext.Result)
            {
                return await stepContext.ReplaceDialogAsync(InitialDialogId, userdetails, cancellationToken);

            }
            else
            {
                await stepContext.Context.SendActivityAsync(MessageFactory.Text("ok"));
                return await stepContext.EndDialogAsync(userdetails, cancellationToken);
            }
        }
    }
}
