﻿using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Schema.Teams;
using Microsoft.EntityFrameworkCore;
using System;
using System.Threading;
using System.Threading.Tasks;
using testfinale;
using testfinale.Dialogs;
using testfinale.Dialogs.tasks;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace CoreBotWithTests1.Dialogs.tasks
{
    public class addinvoice : CancelAndHelpDialog
    {
        public addinvoice() : base(nameof(addinvoice))
        {
            var WaterFallSteps = new WaterfallStep[]
          {
                TaskStepAsync,
                ActStepAsync ,
                MoreTaskStepAsync,
                Summarytaskasync
          };
            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), WaterFallSteps));
            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(new ConfirmPrompt(nameof(ConfirmPrompt)));

            AddDialog(new addmoreinvoice());

            InitialDialogId = nameof(WaterfallDialog);
        }



        private async Task<DialogTurnResult> TaskStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var userdetails = (user)stepContext.Options;
            if (userdetails.name == null)
            {
                return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
                {
                    Prompt = MessageFactory.Text("what invoice do you want to create")
                }, cancellationToken);
            }
           return await stepContext.NextAsync(userdetails.name,cancellationToken);

        }

        private async Task<DialogTurnResult> ActStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var userdetails = (user)stepContext.Options;
            stepContext.Values["invoice"] = (string)stepContext.Result;
            userdetails.invoicelist.Add((string)stepContext.Values["invoice"]);
            return await stepContext.PromptAsync(nameof(ConfirmPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("would you like to add more ivoices")
            }, cancellationToken);
        }

        private async Task<DialogTurnResult> MoreTaskStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var userdetails = (user)stepContext.Options;
            if ((bool)stepContext.Result)
            {
                return await stepContext.BeginDialogAsync(nameof(addmoreinvoice), userdetails, cancellationToken);
            }
            else
            {
                return await stepContext.NextAsync(userdetails, cancellationToken);
            }
        }
        private async Task<DialogTurnResult> Summarytaskasync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var userdetails = (user)stepContext.Result;
            await stepContext.Context.SendActivityAsync(MessageFactory.Text("here are the invoices you created"),
                cancellationToken);
            for (int i = 0; i < userdetails.invoicelist.Count; i++)
            {
                await stepContext.Context.SendActivityAsync(MessageFactory.Text(userdetails.invoicelist[i]), cancellationToken);

            }
            return await stepContext.EndDialogAsync(userdetails, cancellationToken);

        }
    }
}


