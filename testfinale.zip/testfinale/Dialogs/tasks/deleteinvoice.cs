﻿using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Dialogs.Choices;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace testfinale.Dialogs.tasks
{
    public class deleteinvoice : ComponentDialog

    {

        public deleteinvoice() : base(nameof(deleteinvoice))
        {
            var WaterFallSteps = new WaterfallStep[]
          {
               AskStepAsync ,

               ActStepAsync
          };
            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), WaterFallSteps));
            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(new ChoicePrompt(nameof(ChoicePrompt)));

            InitialDialogId = nameof(WaterfallDialog);
        }



        private async Task<DialogTurnResult> ActStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            await stepContext.Context.SendActivityAsync(MessageFactory.Text("choose one of the options "));
            List<string> steps = new List<string> { "remove all", "remove specific one" };
            return await stepContext.PromptAsync(nameof(ChoicePrompt), new PromptOptions
            {
                Choices = ChoiceFactory.ToChoices(steps),
            }, cancellationToken);
        }


        private async Task<DialogTurnResult> AskStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {

            stepContext.Values["choices"] = ((FoundChoice)stepContext.Result).Value;
            string operation = (string)stepContext.Result;
            await stepContext.Context.SendActivityAsync(MessageFactory.Text($"you have selected {operation}"), cancellationToken);
            var userdetails = (user)stepContext.Result;
            if ("remove all".Equals(operation))
            {
                userdetails.invoicelist.Remove("purchase invoice");

            }
            return await stepContext.NextAsync(userdetails);
        }


    }
}
