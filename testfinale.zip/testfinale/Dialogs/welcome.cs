﻿using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Schema;
using Microsoft.Bot.Schema.Teams;
using Microsoft.EntityFrameworkCore;
using System;
using System.Threading;
using System.Threading.Tasks;
using testfinale;
using testfinale.Dialogs;
using testfinale.Dialogs.tasks;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace CoreBotWithTests1.Dialogs.tasks
{
    public class welcome : CancelAndHelpDialog
    {
        public welcome() : base(nameof(welcome))
        {
            var WaterFallSteps = new WaterfallStep[]
          {
                TaskStepAsync
                
               
          };
            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), WaterFallSteps));
            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(new ConfirmPrompt(nameof(ConfirmPrompt)));

            

            InitialDialogId = nameof(WaterfallDialog);
        }



        private async Task<DialogTurnResult> TaskStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var
                messageText =
                        "Hello! How can I assist you today?"
                        ;
            var
            promptMessage = MessageFactory.Text(messageText, messageText, InputHints.ExpectingInput);
            await
            stepContext.Context.SendActivityAsync(promptMessage, cancellationToken);
            return
            await
            stepContext.EndDialogAsync();
        }

       

        

        
    }
}


