﻿using System.Collections.Generic;

namespace testfinale
{
    public class user
    {

        public List<string> invoicelist = new List<string>();
        public string name { get; set; }
    }
}
