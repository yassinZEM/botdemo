﻿using System;
using System.Collections.Generic;

namespace testfinale.Models
{
    public partial class User
    {
        public string UId { get; set; }
        public string UName { get; set; }
    }
}
