﻿using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.Extensions.Configuration;

namespace testfinale.Models
{
    public partial class test1888Context : DbContext
    {
        public test1888Context()
        {
        }

        public test1888Context(DbContextOptions<test1888Context> options)
            : base(options)
        {
        }

        public virtual DbSet<Invoice1> Invoice1s { get; set; }
        public virtual DbSet<User> Users { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            var builder = new ConfigurationBuilder()
                              .SetBasePath(Directory.GetCurrentDirectory())
                              .AddJsonFile("appsettings.json");
            var config = builder.Build();
            var connectionString = config.GetConnectionString("DBConnectionString");

            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(connectionString);
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Invoice1>(entity =>
            {
                entity.HasKey(e => e.InId)
                    .HasName("pk_in");

                entity.ToTable("Invoice1");

                entity.Property(e => e.InId)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("in_ID");

                entity.Property(e => e.InName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("in_NAME");
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.HasKey(e => e.UId)
                    .HasName("pk_emp_id");

                entity.ToTable("User");

                entity.Property(e => e.UId)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("U_ID");

                entity.Property(e => e.UName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("U_NAME");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
