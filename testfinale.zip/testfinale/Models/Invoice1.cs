﻿using System;
using System.Collections.Generic;

namespace testfinale.Models
{
    public partial class Invoice1
    {
        public string InId { get; set; }
        public string InName { get; set; }
    }
}
