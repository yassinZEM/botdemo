﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using testfinale;
using testfinale.Models;

namespace testfinale.utility
{
    public class UserRepository : IUserRepository
    {
        test1888Context context;
        public test1888Context Context { get { return context; } }
        public UserRepository()
        {
            context = new test1888Context();
        }

        public User FetchuserDetails(string uid)
        {
            User user1;
            try
            {
                user1 = (from r in Context.Users
                         where r.UId == uid
                         select r).FirstOrDefault();
            }
            catch (Exception)
            {
                throw;
            }
            return user1;
        }

        public bool Insertuser(User user2)
        {
            bool status = false;
            try
            {
                Context.Users.Add(user2);
                Context.SaveChanges();
                status = true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return status;
        }
    }
}