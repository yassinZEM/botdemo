﻿using testfinale.Models;

namespace testfinale.utility
{
    public interface IUserRepository
    {
        public User FetchuserDetails(string uid);
        public bool Insertuser(User user2);


    }
}
